#2018051604101 陈勇 软工四班
def digui(n):
    if(n==0):return 0
    return n+digui(n-1)

if __name__ == "__main__":
    n=int(input("请输入整数："))
    print('前n项和为：')
    print(digui(n))
