#2018051604101 陈勇 软工四班

def gongbeushu(m, n):

   if m > n:
       greater = m
   else:
       greater = n
 
   while(True):
       if((greater % m == 0) and (greater % n == 0)):
           break
       else :greater += 1
 
   return greater
if __name__ == "__main__":
    m=int(input('请输入第一个整数：'))
    n=int(input('请输入第二个整数：'))
    print('最小公倍数是：')
    print(gongbeushu(m,n))