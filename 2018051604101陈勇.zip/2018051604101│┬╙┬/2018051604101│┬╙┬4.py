#2018051604101 陈勇 软工四班

def newusers(ks):
    m=input('请输入新用户名:')
    if m in ks:
        print('用户名已经存在，请从新输入')
        newusers(ks)
    else:
        n=input('请设置密码：')
        ks[m]=n
        print('注册成功:')
    pass
def oldusers(ks):
    m=input('请输入用户名：')
    n=input('请输入密码：')
    if (m in ks) and (n==ks[m]):
        print(m,'welcom back')
    else:
        print('login incorrect')
        login(ks)
    pass
def login(ks):
    print('新用户登录输入1')
    print('老用户登录输入2')
    print('退出请输入0')
    k=int(input('请输入选项：'))
    if(k==1):
        newusers(ks)
    elif(k==2):
        oldusers(ks)
    elif(k==0):
        pass
    else:
        print('输入错误.')
        login()
    pass
if __name__ == "__main__":
    ks={'minmin':'12345','python':'12345'}#初始化字典
    login(ks)