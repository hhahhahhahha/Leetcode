#2018051604101 陈勇 软工四班

def encryption(str):
    str1=list(str)
    for i in range(len(str1)):
        if(str1[i]=='Y'): str1[i]='A'
        elif(str1[i]=='Z'): str1[i]='B'
        elif(str1[i]=='y'): str1[i]='a'
        elif(str1[i]=='z'): str1[i]='b'
        else:
            str1[i]=chr(ord(str1[i])+2)
    str=''.join(str1)
    #print(str1)
    return str

if __name__ == "__main__":
    k =input('请输入字符串：')
    print('加密过后的字符串：')
    print(encryption(k))
